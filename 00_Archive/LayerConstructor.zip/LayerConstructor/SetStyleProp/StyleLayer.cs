﻿using Autodesk.Civil.DatabaseServices.Styles;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Windows.Forms;

namespace SetStyleProp
{
    class StyleLayer
    {
        readonly StyleBase Stylebase;
        readonly PropertyInfo PropInf;
        readonly Type ObjectType;
        readonly Type RootType;
        readonly IMongoDatabase Database;

        public StyleLayer(StyleBase stylebase, PropertyInfo pf, Type objectType, Type rootType, IMongoDatabase db)
        {
            Stylebase = stylebase;
            PropInf = pf;
            ObjectType = objectType;
            RootType = rootType;
            Database = db;
        }

        public string GetLayerName()
        {
            List<string> StyleNameFields = new List<string>();
            StyleNameFields = GetStyleNameFields();
            string delimeter = "-";
            string layerName = StyleNameFields.Aggregate((i, j) => i + delimeter + j);

            return layerName;
        }

        List<string> GetStyleNameFields()
        {
            List<string> styleNameFields = SplitString(Stylebase.Name);

            GetFields3_5(out string code3, out string code5);

            //Add codes of type of Civil3D object to style name
            if (code3 != "")
                styleNameFields.Add(code3);
            if (code5 != "")
                styleNameFields.Add(code5);
            

            return styleNameFields;
        }

        List<string> SplitString(string line)
        {
            char separator = Convert.ToChar("-");
            string[] SplitedLineArray = line.Split(separator);

            List<string> SplitedLine = new List<string>(SplitedLineArray);

            return SplitedLine;
        }

        void GetFields3_5(out string code3, out string code5)
        {
            string description = "";
            code5 = "";

            if (RootType.Name == "StylesRoot")
                description = PropInf.Name;
            else if (RootType.Name.Contains("Label"))
            {
                description = RootType.Name;
                code5 = "МЕТК";
            }           

                Mongo mongo = new Mongo(Database);
             code3 = mongo.GetStyleTypeCode(description);

           
        }

       

    }
}
