﻿using Autodesk.Civil.DatabaseServices.Styles;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Windows.Forms;

namespace SetStyleProp
{
    class StyleLayer
    {
        readonly StyleBase Stylebase;
        readonly PropertyInfo PropInf;
        readonly Type ObjectType;
        readonly IMongoDatabase Database;

        public StyleLayer(StyleBase stylebase, PropertyInfo pf, Type objectType, IMongoDatabase db)
        {
            Stylebase = stylebase;
            PropInf = pf;
            ObjectType = objectType;
            Database = db;
        }

        public string GetLayer()
        {
            List<string> StyleNameFields = new List<string>();
            StyleNameFields = GetStyleNameFields();
            string delimeter = "-";
            string layerName = StyleNameFields.Aggregate((i, j) => i + delimeter + j);

            return layerName;
        }

        List<string> GetStyleNameFields()
        {
            List<string> styleNameFields = SplitString(Stylebase.Name);
            //styleNameFields.RemoveAt(0);

            GetFields3_5(out string code3, out string code5);

            //Add codes of type of Civil3D object to style name
            styleNameFields.Add(code3);
            if (code5 != "")
                styleNameFields.Add(code5);
            

            return styleNameFields;
        }

        List<string> SplitString(string line)
        {
            char separator = Convert.ToChar("-");
            string[] SplitedLineArray = line.Split(separator);

            List<string> SplitedLine = new List<string>(SplitedLineArray);

            return SplitedLine;
        }

        void GetFields3_5(out string code3, out string code5)
        {
            string description = ObjectType.Name;

            if (description.Contains("Label"))
                code5 = "МЕТК";
            else if (description.Contains("Set"))
                code5 = "ДАНН";
            else if (description.Contains("Table"))
                code5 = "ТАБЛ";
            else
                code5 = "";


            //Remove redundant word
            description = GetFieldDesciption(description);


                Mongo mongo = new Mongo(Database);
             code3 = mongo.GetStyleTypeCode(description);

           
        }

        string GetFieldDesciption(string typeName)
        {
            List<string> stringsToRemove = new List<string>()
            {
                "Style",
                "Label",
                "Set",
                "Table"
            };

            foreach (string rem in stringsToRemove)
            {
                if (typeName.Contains(rem))
                {
                    int index = typeName.IndexOf(rem);
                    typeName = typeName.Remove(index, rem.Length);
                }
            }
           

            return typeName;
        }

    }
}
